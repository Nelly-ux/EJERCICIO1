# practica1
 
